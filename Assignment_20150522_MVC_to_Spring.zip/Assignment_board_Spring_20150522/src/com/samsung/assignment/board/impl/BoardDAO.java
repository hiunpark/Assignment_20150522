package com.samsung.assignment.board.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.samsung.assignment.board.vo.BoardVO;
import com.samsung.assignment.board.vo.Count_checkVO;
@Repository
public class BoardDAO {
	@Autowired
	private SqlSession sqlSession;
	
	/**
	 * 페이지 개수를 가져오는 메서드
	 * @return pages
	 */
	public int getPagingNum(){
		return sqlSession.selectOne("getPagingNum");
	}
	
	/**
	 * 게시글 리스트 가져오는 메서드
	 * @param pageNum
	 * @return
	 */
	public ArrayList<BoardVO> list(int page, int interval) {
		HashMap<String, Integer> map = new HashMap<>();
		List<BoardVO> boardList = new ArrayList<BoardVO>();

		int start = 1; 
		int end = interval; 
		if (page > 1) {
			start = (page - 1) * interval + 1;
			end = page * interval;
		}
		map.put("start", start);
		map.put("end",  end);
		boardList = sqlSession.selectList("list", map);
		return (ArrayList)boardList;
	}
	/**
	 * 게시글 개수를 가져오는 메서드
	 * @return
	 */
	public int listCount() {
		int count = 0;
		count = sqlSession.selectOne("listCount");
		return count;
	}
	/**
	 * 하나의 게시글을 가져오는 메서드
	 * @param vo
	 * @return
	 */
	public BoardVO getBoardView(BoardVO vo){
	return sqlSession.selectOne("getBoardView", vo);
	}
	
	/**
	 * 게시글을 삽입하는 메서드
	 * '새글 쓰기'에만 적용됨
	 * @param vo
	 * @return
	 */
	public boolean insertNewBoard(BoardVO vo){
		int result = sqlSession.insert("insertNewBoard", vo);
		return result>0?true:false;
	}
	
	/**
	 * 답글을 삽입하는 메서드
	 * '답글 쓰기'에만 적용됨
	 * @param vo
	 * @return
	 */
	public BoardVO insertReplyBoard(BoardVO vo){
		int result = sqlSession.insert("insertReplyBoard", vo);
		if(result>0){
			return sqlSession.selectOne("getMaxSeqBoard");
		}else{
			return null;
		}
	}
	
	/**
	 * 답글 작성 시 답글의 BOARD_Step을 1 증가시키기 위해 작성된 답글 목록 중 BOARD_Step을 리턴하는 함수 
	 * @param vo
	 * @return
	 */
	public int selectMaxStep(int board_parentSeq){
		return sqlSession.selectOne("selectMaxStep");
	}
	
	/**
	 * 중간에 답글이 달릴 경우 그 아래에 있던 답글들의 step을 +1시키는 메서드
	 * @param board_step
	 * @return
	 */
	public boolean updateStep(int board_parentSeq, int board_step){
		HashMap<String, Integer> map = new HashMap<>();
		map.put("board_parentSeq", board_parentSeq);
		map.put("board_step", board_step);
		int result = sqlSession.update("updateStep", map);
		return result>0?true:false;
	}
	
	/**
	 * 답글 작성 시 윗 글의 LVL을 1 증가시키기 위해 BOARD_LVL을 리턴하는 함수
	 * @param board_seq
	 * @return
	 */
	public int selectLvl(int board_seq){
		int result = sqlSession.selectOne("selectLvl", board_seq);
		return result>0?result:0;
	}
	
	/**
	 * 답글 작성 시 가장 첫번째 글의 번호를 찾아서 리턴하는 메서드
	 * @param board_parentSeq
	 * @return
	 */
	public int selectBoardSeq(int board_parentSeq){
		int result = sqlSession.selectOne("selectBoardSeq", board_parentSeq);
		return result>0?result:0;
	}
	
	/**
	 * 게시글의 제목과 내용을 수정하는 메서드
	 * @param vo
	 * @return
	 */
	public boolean updateBoard(BoardVO vo){
		return sqlSession.update("updateBoard", vo)>0?true:false;
	}
	
	/**
	 * 게시글을 삭제하기 전에 답글이 있는지 조회하는 메서드
	 * @param vo
	 * @return
	 */
	public boolean deleteCheckBoard(BoardVO vo){
		int result = sqlSession.selectOne("deleteCheckBoard", vo);
		return result>1?false:true;
	}
	
	/**
	 * 게시글을 삭제하는 메서드
	 * 데이터베이스에서 삭제시키지 않으며, 
	 * 제목을 '삭제된 글입니다'라고 update한 뒤 조회하지 못하도록 함
	 * @param vo
	 * @return
	 */
	public boolean deleteBoard(BoardVO vo){
		int result = sqlSession.update("deleteBoard", vo);
		return result>0?true:false;
	}
	
	/**
	 * 로그인한 사용자가 게시글을 조회했는지 확인하는 메서드
	 * @param user_id
	 * @return
	 */
	public Count_checkVO selectCountCheckToday(BoardVO vo) {
		return sqlSession.selectOne("selectCountCheckToday", vo);
	}
	
	/**
	 * 사용자가 오늘 게시글을 조회했을 경우 해당 테이블에 조회했다는 데이터를 넣는 메서드
	 * @param user_id
	 * @return
	 */
	public boolean insertCountCheckToday(BoardVO vo) {
		return sqlSession.insert("insertCountCheckToday", vo)>0?true:false;
	}
	
	/**
	 * 사용자가 이전에 게시글을 조회한 이력이 있는 경우 날짜만 오늘로 바꾸기
	 * @param vo
	 * @return
	 */
	public boolean updateCount_CheckDate(BoardVO vo) {
		int result = sqlSession.update("updateCount_CheckDate", vo);
		return result>0?true:false;
	}
	
	/**
	 * 조회수를 1 증가시키는 메서드
	 * @param vo
	 */
	public void updateBoardCnt(BoardVO vo) {
		sqlSession.update("updateBoardCnt", vo);
	}
	
	/**
	 * 제목으로 검색하는 메서드
	 * @param search
	 */
	public ArrayList<BoardVO> searchByTitle(String search, int page, int interval) {
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		HashMap<String, Object> map = new HashMap<>();
		map.put("search", search);

		int start = 1; 
		int end = interval; 
		if (page > 1) {
			start = (page - 1) * interval + 1;
			end = page * interval;
		}
		map.put("start", start);
		map.put("end", end);
		boardList = sqlSession.selectList("searchByTitle", map);
		return (ArrayList)boardList;
	}
	
	/**
	 * 내용으로 검색하는 메서드
	 * @param search
	 * @return 
	 */
	public ArrayList<BoardVO> searchByContent(String search, int page, int interval) {
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		HashMap<String, Object> map = new HashMap<>();
		map.put("search", search);

		int start = 1; 
		int end = interval; 
		if (page > 1) {
			start = (page - 1) * interval + 1;
			end = page * interval;
		}
		map.put("start", start);
		map.put("end", end);
		boardList = sqlSession.selectList("searchByContent", map);
		return (ArrayList)boardList;
	}
}
