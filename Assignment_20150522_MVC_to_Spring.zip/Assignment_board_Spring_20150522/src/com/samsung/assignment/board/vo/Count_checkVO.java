package com.samsung.assignment.board.vo;

import java.sql.Date;

import org.springframework.stereotype.Component;
@Component
public class Count_checkVO {
	private int board_seq;
	private String user_id;
	private Date checkdate;
	public Count_checkVO() {
		super();
	}
	public Count_checkVO(int board_seq, String user_id, Date checkdate) {
		super();
		this.board_seq = board_seq;
		this.user_id = user_id;
		this.checkdate = checkdate;
	}
	public int getBoard_seq() {
		return board_seq;
	}
	public void setBoard_seq(int board_seq) {
		this.board_seq = board_seq;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public Date getCheckdate() {
		return checkdate;
	}
	public void setCheckdate(Date checkdate) {
		this.checkdate = checkdate;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Count_checkVO [board_seq=");
		builder.append(board_seq);
		builder.append(", user_id=");
		builder.append(user_id);
		builder.append(", checkdate=");
		builder.append(checkdate);
		builder.append("]");
		return builder.toString();
	}
}
