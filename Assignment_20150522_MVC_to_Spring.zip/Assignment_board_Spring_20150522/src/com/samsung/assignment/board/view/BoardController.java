package com.samsung.assignment.board.view;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestParam;

import com.samsung.assignment.board.impl.BoardDAO;
import com.samsung.assignment.board.vo.BoardVO;
import com.samsung.assignment.board.vo.Count_checkVO;
import com.samsung.assignment.controller.AdvancedPageUtility;

@Controller
public class BoardController {
	@Autowired
	private BoardDAO dao;
	
	public String getBoardList(@RequestParam("pageNo") String pageNo, Model mav, BoardVO vo) {
		int pageNum = 1;
		if(pageNo!=null){
			pageNum = Integer.parseInt(pageNo);
		}
		int interval = 10;
		// 게시글 전체 가져오기
		ArrayList<BoardVO> boardList = dao.list(pageNum, interval);
		// 게시글 수 가져오기
		int total = dao.listCount();
		// total이 0이면 1, 아니면 total
		total = total==0?1:total;
		try {
			AdvancedPageUtility bar = new AdvancedPageUtility(interval, total, pageNum, "images/");
			mav.addAttribute("pageLink", bar.getPageBar());
			mav.addAttribute("boardList", boardList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "board.jsp";
	}
	
	public String getBoardView(Model mav, BoardVO vo, HttpSession session) {
		// 게시글 가져오기
		BoardVO board = dao.getBoardView(vo);
		
		mav.addAttribute("board", board);
		
		// 게시글 조회수 늘리기
		
		// 세션의 유저 정보 가져오기
		String user_id = "";
		// 현재 날짜 가져오기
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date currentTime = new java.util.Date();
		String dTime = formatter.format(currentTime);
		java.sql.Date checkDate = java.sql.Date.valueOf(dTime);
		// 만약 로그인한 유저가 있다면
		if(session.getAttribute("user_id")!=null){
			user_id = (String)session.getAttribute("user_id");
			vo.setUser_id(user_id);
			// 1. count_check 테이블에 가서 사용자가 오늘 로그인한 뒤 게시글을 조회했는지 확인
			// 조회했으면 true, 조회하지 않았으면 false
			Count_checkVO checkVO = dao.selectCountCheckToday(vo);
			
			// 2-1. 만약 처음 조회한다면 count_check 테이블에 유저, 날짜를 집어넣고
			if(checkVO.getBoard_seq()==0){
				boolean done = dao.insertCountCheckToday(vo);
				// 2-2. 조회수를 1 증가시키기
				if(done){
					dao.updateBoardCnt(vo);
					return "boardView.jsp";
				}
			
				// 3-1. 만약 테이블에 데이터가 있으나 날짜가 같지 않을 경우 
			}else if(checkVO.getUser_id().equals(user_id)  && !checkDate.equals(checkVO.getCheckdate())){
				
				// 3-2. 테이블의 날짜 데이터를 오늘로 update하고
				vo.setBoard_regdate(checkDate);
				boolean done = dao.updateCount_CheckDate(vo);
				// 3-3. 조회수를 1 증가시키기
				if(done){
					dao.updateBoardCnt(vo);
					return "boardView.jsp";
				}
				// 4-1. 만약 테이블에 유저 정보와 오늘 날짜가 있다면
			}else if(checkVO.getUser_id().equals(user_id) /*날짜 오늘이면*/){
				// 조회수 증가시키지 않고 그냥 리턴
				return "boardView.jsp";
			}
			
		}
		// 만약 로그인한 유저가 없다면
		// 그 외에는 IP로 추적해야 하나...skip
		// 조회수만 증가
		dao.updateBoardCnt(vo);
		return "boardView.jsp";
	}
	
	public String insertNewBoard(Model mav, HttpSession session, BoardVO vo) {
		
		if(session.getAttribute("user_id")==null){
			mav.addAttribute("msg", "세션이 만료되어 로그아웃되었습니다");
			return "getBoardList.do";
		}
		
		boolean done = dao.insertNewBoard(vo);
		if(done){
			return "getBoardList.do";
		}else{
			mav.addAttribute("msg", "게시글 DB에 저장 실패!");
			mav.addAttribute("writingBoard", vo);
			return "write.jsp";
		}
	}
	
	public String insertReply(@RequestParam("board_grandParentSeq") String board_gps, Model mav, HttpSession session, BoardVO vo) {
		if(session.getAttribute("user_id")==null){
			mav.addAttribute("msg", "세션이 만료되어 로그아웃되었습니다");
			return "getBoardList.do";
		}
		
		String user_id = (String) session.getAttribute("user_id");
		int board_grandParentSeq = Integer.parseInt(board_gps);
		int board_parentSeq = vo.getBoard_parentSeq();
		
		// step과 lvl을 가져와서 1씩 증가시키기
		BoardDAO dao = new BoardDAO();
		// 바로 윗글의 step을 가져오기
		int parentStep = dao.selectMaxStep(board_parentSeq);
		// 바로 윗글에 대한 lvl을 가져오기
		int parentLvl = dao.selectLvl(board_parentSeq);
		vo.setBoard_step(parentStep+1);
		vo.setBoard_lvl(parentLvl+1);
		
		// 새로 생성되는 답글들의 아래 답글들 step을 +1시키는 메서드
		boolean done = true;
		done = dao.updateStep(board_grandParentSeq, parentStep);
		BoardVO board = dao.insertReplyBoard(vo);
		// 삽입 완료 후 작성된 게시글 페이지로 이동
		if(board!=null && done){
			return "getBoardView.do?board_seq="+board.getBoard_seq();
		}else{
			mav.addAttribute("msg", "답글 저장 중 에러 발생");
			mav.addAttribute("writingBoard", vo);
			return "reply.jsp";
		}
	}
	
	public String reply(Model mav, BoardVO vo) {
		BoardVO board = dao.getBoardView(vo);
		int grandParentBoardSeq = dao.selectBoardSeq(vo.getBoard_seq());
		// 원글 넣어서 돌려보내기
		mav.addAttribute("parentBoard", board);
		// 가장 첫번째 글도 함께 넣기
		mav.addAttribute("grandParentBoardSeq", grandParentBoardSeq);
		return "reply.jsp";
	}
	
	public String updateSave(Model mav, BoardVO vo, HttpSession session) {
		boolean done = dao.updateBoard(vo);
		mav.addAttribute("", done);
		return getBoardView(mav, vo, session);
	}
	
	public String deleteBoard(Model mav, BoardVO vo) {
		// 답글이 있는 글인지 조회
		boolean canDelete = dao.deleteCheckBoard(vo);
		if(canDelete){
			// 답글이 없으면 게시글 삭제
			boolean done = dao.deleteBoard(vo);
			if(done){
				mav.addAttribute("msg", "삭제 완료");
				return "getBoardList.do";
			}else{
				mav.addAttribute("msg", "삭제 도중 에러 발생!");
				mav.addAttribute("board_seq", vo.getBoard_seq());
				return "getBoardView.do";
			}
		}else{
			// 답글이 있는 글이면 게시글 삭제하지 못하게 함
			mav.addAttribute("msg", "답글이 있는 글은 삭제할 수 없습니다");
			mav.addAttribute("board_seq", vo.getBoard_seq());
			return "getBoardView.do";
		}
	}
	
	public String searchBoard(@RequestParam("pageNo") String pageNo, @RequestParam("option") String search, @RequestParam("content") String content,
			Model mav) {
		int pageNum = 1;
		if(pageNo!=null){
			pageNum = Integer.parseInt(pageNo);
		}
		ArrayList<BoardVO> boardList = new ArrayList<>();
		int interval = 10;
		int total = 0;
		// 제목과 아이디에 대해 검색
		if(search.equals("title")){
			boardList = dao.searchByTitle(content, pageNum, interval);
			// 게시글 수 가져오기
			total = boardList.size();
		}else if(search.equals("content")){
			boardList = dao.searchByContent(content, pageNum, interval);
			total = boardList.size();
		}
		// total이 0이면 1, 아니면 total
		total = total==0?1:total;
		try {
			AdvancedPageUtility bar = new AdvancedPageUtility(interval, total, pageNum, "images/");
			mav.addAttribute("pageLink", bar.getPageBar());
			mav.addAttribute("boardList", boardList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "board.jsp";
	}
}
