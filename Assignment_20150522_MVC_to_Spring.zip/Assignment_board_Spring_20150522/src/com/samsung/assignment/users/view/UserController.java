package com.samsung.assignment.users.view;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import com.samsung.assignment.users.impl.UserDAO;
import com.samsung.assignment.users.vo.UserVO;

@Controller
public class UserController {
	@Autowired
	private UserDAO dao;
	
	public String login(HttpSession session, UserVO vo, Model mav) {
		UserVO loginUser = dao.login(vo);
		String msg = "";
		if(loginUser.getUser_id()==null){
			msg = "아이디를 확인하세요";
			mav.addAttribute("msg", msg);
		}else if(loginUser.getPassword().equals("uncorrect")){
			msg = "비밀번호를 확인하세요";
			mav.addAttribute("inputId", vo.getUser_id());
			mav.addAttribute("msg", msg);
		}else{
			session.setAttribute("user_id", loginUser.getUser_id());
			session.setAttribute("user_name", loginUser.getUser_name());
			msg = "성공";
		}
		// 게시글 가져가기
		return "getBoardList.do";
	}
	
	public String logout(HttpSession session) {
		session.invalidate();
		return "getBoardList.do";
	}
}
